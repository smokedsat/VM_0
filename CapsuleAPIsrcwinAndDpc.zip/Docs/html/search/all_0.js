var searchData=
[
  ['accumulatedfatigue_0',['accumulatedFatigue',['../structcl_c_n_f_b_metrics_productivity_values.html#a57afb1b1b3f6f7da2c2823919b671655',1,'clCNFBMetricsProductivityValues']]],
  ['alpha_1',['alpha',['../structcl_c_physiological_states_baselines.html#a81bb6a9bfbbad9c9c4e71dc34417f944',1,'clCPhysiologicalStatesBaselines']]],
  ['alphagravity_2',['alphaGravity',['../structcl_c_physiological_states_baselines.html#a709e560893e2bdbf5216f358c926ddbe',1,'clCPhysiologicalStatesBaselines']]],
  ['alpharangebegin_3',['alphaRangeBegin',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#ae19299e0d072dc21f4861a51c227e9af',1,'clCNFBMetricsProductivityIndividualIndexes']]],
  ['alpharangeend_4',['alphaRangeEnd',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#a74e2eb5090049b8ec86f7fd0572d470b',1,'clCNFBMetricsProductivityIndividualIndexes']]],
  ['anger_5',['anger',['../structcl_c_emotional_states.html#a8485e3c76c71516fb85b4a998689a35d',1,'clCEmotionalStates']]],
  ['artifacted_6',['artifacted',['../structcl_c_cardio_data.html#a65a251f9ee05c2a55c5d29ec374a43db',1,'clCCardioData']]],
  ['artifactsdata_7',['artifactsData',['../structcl_c_n_f_b_user_artifacts.html#a71454f6736a9f76ca77e9f0c3ac6b581',1,'clCNFBUserArtifacts']]],
  ['artifactssize_8',['artifactsSize',['../structcl_c_n_f_b_user_artifacts.html#ab3903863d9c14f4096db87e208e2f57f',1,'clCNFBUserArtifacts']]]
];
