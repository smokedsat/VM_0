var searchData=
[
  ['fatigue_0',['fatigue',['../structcl_c_physiological_states_value.html#a364b4dfaad973e8a7e265c424a8964d0',1,'clCPhysiologicalStatesValue']]],
  ['fatiguebaseline_1',['fatigueBaseline',['../structcl_c_n_f_b_metrics_productivity_baselines.html#a3cb06f08e8a7e7600aeb330a231c9fe7',1,'clCNFBMetricsProductivityBaselines::fatigueBaseline'],['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#af9550a8fc67857171e2d83f5c4b5c9d9',1,'clCNFBMetricsProductivityIndividualIndexes::fatigueBaseline']]],
  ['fatiguegrowthrate_2',['fatigueGrowthRate',['../structcl_c_n_f_b_metrics_productivity_values.html#a23f730d12dee39b22100f4ac7bf2c1a1',1,'clCNFBMetricsProductivityValues']]],
  ['fatiguescore_3',['fatigueScore',['../structcl_c_n_f_b_metrics_productivity_values.html#aa01a6fda85c82de8a4f609b85879c89e',1,'clCNFBMetricsProductivityValues']]],
  ['feedbackdata_4',['feedbackData',['../structcl_c_n_f_b_user_state.html#a4013972d034bb346e8129616201abfa0',1,'clCNFBUserState']]],
  ['feedbacksize_5',['feedbackSize',['../structcl_c_n_f_b_user_state.html#a88a404468f9345e2ab91b87adefd96d7',1,'clCNFBUserState']]],
  ['focus_6',['focus',['../structcl_c_emotional_states.html#a9feccee236cbd5e377bdbf23bd70dc06',1,'clCEmotionalStates']]]
];
