var searchData=
[
  ['kaplanindex_0',['kaplanIndex',['../structcl_c_cardio_data.html#aeef45e1d2ab0b2ab8ca073fbe769df19',1,'clCCardioData']]]
];
