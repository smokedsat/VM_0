var searchData=
[
  ['nfbartifacts_0',['nfbArtifacts',['../structcl_c_physiological_states_value.html#a34c99736d50efb7391a17089aca14dc2',1,'clCPhysiologicalStatesValue']]],
  ['noexcept_1',['NOEXCEPT',['../_c_defines_private_8h.html#a10a59554805ac7ce3905fd3540f98137',1,'CDefinesPrivate.h']]],
  ['none_2',['none',['../structcl_c_physiological_states_value.html#aeb867951ccfae3bf1efebbb18d0b9cb2',1,'clCPhysiologicalStatesValue']]]
];
