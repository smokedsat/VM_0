var searchData=
[
  ['upperfrequency_0',['upperFrequency',['../structcl_c_individual_n_f_b_data.html#a663555e33ff5101323e5ddde732db3c7',1,'clCIndividualNFBData']]]
];
