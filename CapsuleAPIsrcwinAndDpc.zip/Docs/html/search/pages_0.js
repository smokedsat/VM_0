var searchData=
[
  ['capsule_20api_20quick_20start_20guide_0',['Capsule API Quick Start Guide',['../index.html',1,'']]]
];
