var searchData=
[
  ['beta_0',['beta',['../structcl_c_physiological_states_baselines.html#a3f2a65e8d42f07bde4c5f72a84b9ef9a',1,'clCPhysiologicalStatesBaselines']]],
  ['betagravity_1',['betaGravity',['../structcl_c_physiological_states_baselines.html#a331270f74c6c23d9cacab7d7b3426f9a',1,'clCPhysiologicalStatesBaselines']]]
];
