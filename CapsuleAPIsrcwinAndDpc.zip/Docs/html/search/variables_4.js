var searchData=
[
  ['gravitybaseline_0',['gravityBaseline',['../structcl_c_n_f_b_metrics_productivity_baselines.html#a55fa9b7c147d083834b13c48776314a8',1,'clCNFBMetricsProductivityBaselines::gravityBaseline'],['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#af008d08b70f890877c9a5ac5659718bd',1,'clCNFBMetricsProductivityIndividualIndexes::gravityBaseline']]],
  ['gravityscore_1',['gravityScore',['../structcl_c_n_f_b_metrics_productivity_values.html#a15715d7fd3f62af1b88151212744cd6a',1,'clCNFBMetricsProductivityValues']]]
];
