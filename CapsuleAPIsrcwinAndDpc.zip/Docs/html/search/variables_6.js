var searchData=
[
  ['iaf_0',['IAF',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#a82703556b673a30a2cee3f944329e67e',1,'clCNFBMetricsProductivityIndividualIndexes']]],
  ['iapf_1',['IAPF',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#a5f901969b78d630b5b851e93f7b6b335',1,'clCNFBMetricsProductivityIndividualIndexes']]],
  ['iapfpowernormalized_2',['IAPFPowerNormalized',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#ae80c88441e86e4fd8fa634dc70713805',1,'clCNFBMetricsProductivityIndividualIndexes']]],
  ['individualbandwidth_3',['individualBandwidth',['../structcl_c_individual_n_f_b_data.html#a189094f8ad809e3fb355979064bf336f',1,'clCIndividualNFBData']]],
  ['individualfrequency_4',['individualFrequency',['../structcl_c_individual_n_f_b_data.html#a99f2f7f62c1436c05c869d3c904ef72a',1,'clCIndividualNFBData']]],
  ['individualnormalizedpower_5',['individualNormalizedPower',['../structcl_c_individual_n_f_b_data.html#a5df565f03f9a181862204bffe2fb479b',1,'clCIndividualNFBData']]],
  ['individualpeakfrequency_6',['individualPeakFrequency',['../structcl_c_individual_n_f_b_data.html#a111e48a398bafe47053852a8f00dd5cf',1,'clCIndividualNFBData']]],
  ['individualpeakfrequencypower_7',['individualPeakFrequencyPower',['../structcl_c_individual_n_f_b_data.html#ab6f4b374f7dd6593d85b67411908fa01',1,'clCIndividualNFBData']]],
  ['individualpeakfrequencysuppression_8',['individualPeakFrequencySuppression',['../structcl_c_individual_n_f_b_data.html#a62cac2168f3f6db35ec0b928e97a98f5',1,'clCIndividualNFBData']]],
  ['involvement_9',['involvement',['../structcl_c_physiological_states_value.html#adcf421a802c0617e1f39807ea0f8758c',1,'clCPhysiologicalStatesValue']]],
  ['isartifacted_10',['isArtifacted',['../structcl_c_n_f_b_metrics_productivity_individual_indexes.html#ac6afdc0d7f6b3149d5f73c604963d956',1,'clCNFBMetricsProductivityIndividualIndexes']]]
];
