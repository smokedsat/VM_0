var searchData=
[
  ['nfbartifacts_0',['nfbArtifacts',['../structcl_c_physiological_states_value.html#a34c99736d50efb7391a17089aca14dc2',1,'clCPhysiologicalStatesValue']]],
  ['none_1',['none',['../structcl_c_physiological_states_value.html#aeb867951ccfae3bf1efebbb18d0b9cb2',1,'clCPhysiologicalStatesValue']]]
];
