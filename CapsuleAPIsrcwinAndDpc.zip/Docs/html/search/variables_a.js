var searchData=
[
  ['productivitybaseline_0',['productivityBaseline',['../structcl_c_n_f_b_metrics_productivity_baselines.html#a6385c1fbf7e980539e64988531526b0d',1,'clCNFBMetricsProductivityBaselines']]]
];
