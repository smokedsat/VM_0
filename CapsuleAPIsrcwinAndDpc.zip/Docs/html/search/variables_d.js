var searchData=
[
  ['timestamp_0',['timestamp',['../structcl_c_n_f_b_user_state.html#a98cad9d2da8fd04cddfc03f6aa200264',1,'clCNFBUserState::timestamp'],['../structcl_c_n_f_b_user_artifacts.html#a93b6a2fa3d515da53ef36b5e76376a4b',1,'clCNFBUserArtifacts::timestamp']]]
];
